<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/wishlist_cart.php';
// Fetch categories with sub-categories
$select_categories = $conn->prepare("SELECT * FROM `categories`");
$select_categories->execute();

// Function to fetch sub-categories for a given category ID
function fetchSubCategories($conn, $categoryId) {
   $select_sub_categories = $conn->prepare("SELECT * FROM `sub_categories` WHERE `category_id` = ?");
   $select_sub_categories->execute([$categoryId]);
   $subCategories = $select_sub_categories->fetchAll(PDO::FETCH_ASSOC);
   return $subCategories;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>KinBech.Com</title>

   <!-- Bootstrap CSS -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <style>
        .category-section {
         background-color: #f0f0f0;
         padding: 15px;
         border-radius: 14px;
         margin-bottom: 15px;
      }
      .category-list {
         list-style-type: none;
         padding: 0;
         margin: 0;
      }
      .category-list li {
         padding: 10px 0;
         cursor: pointer;
         position: relative;
      }
      .category-list li:hover {
         background-color: #e0e0e0;
      }
      .category-list li .sub-categories {
         display: none;
         position: absolute;
         top: 100%;
         left: 0;
         background-color: #fff;
         box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
         z-index: 1;
         width: 200px; /* Adjust width as needed */
         padding: 10px;
         border-radius: 5px;
      }
      .category-list li:hover .sub-categories {
         display: block;
      }
      .category-list li .sub-categories ul {
         padding: 0;
         margin: 0;
         list-style-type: none;
      }
      .category-list li .sub-categories ul li {
         padding: 5px 0;
      }
      .product-img {
         width: 200px;
         height: 200px;
         object-fit: cover;
         margin: 0 auto;
      }
      .product-container {
         display: flex;
         flex-wrap: wrap;
         gap: 1rem;
         justify-content: center;
      }
      .product-item {
         flex: 0 1 calc(16.66% - 1rem); /* Show 6 products per row */
         box-sizing: border-box;
      }
      .card {
         border: 1px solid #ddd;
         border-radius: 10px;
         overflow: hidden;
         transition: transform 0.3s ease, box-shadow 0.3s ease;
      }
      .card:hover {
         transform: translateY(-10px);
         box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
      }
      .card-body {
         padding: 1rem;
      }
      .btn-wishlist, .btn-quickview {
         margin-top: 0.5rem;
      }
      
    .navbar {
      background-color: #f85606;
    }
    .navbar-brand img {
      max-height: 50px;
      margin-right: 15px;
    }
    .navbar .form-control {
      border-radius: 20px;
    }

    .product {
      border: 1px solid #f0f0f0;
      margin-bottom: 30px;
      transition: transform 0.3s ease-in-out;
    }
    .product:hover {
      transform: scale(1.05);
    }
    .product img {
      max-width: 100%;
      height: auto;
    }
    .product-info {
      padding: 15px;
    }
    .cart {
      background-color: #f8f9fa;
      padding: 15px;
      margin-top: 15px;
    }

    .category-section {
      background-color: #f0f0f0;
      padding: 15px;
      min-height: 200px; /* Example height, adjust as needed */
      border-radius: 14px;
    }
    .category-slider img {
      max-width: 100%;
      height: auto;
    }

    /* Category Cards Custom Styling */
    .category-cards .card {
      border: none;
      transition: transform 0.3s ease-in-out;
      box-shadow: 0 0 10px rgba(0,0,0,0.1); /* Adding shadow for depth */
    }
    .category-cards .card:hover {
      transform: translateY(-5px); /* Lift card on hover */
    }
    .category-cards .card img {
      max-width: 100px;
      height: 100px;
    }
    .category-cards .card-title {
      text-align: center;
      margin-top: 10px;
    }

    /* Footer */
    footer {
      background-color: #f0f0f0;
      padding: 20px 0;
      color: #333;
      text-align: center;
      font-size: 14px;
      margin-top: 30px;
    }
    footer a {
      color: #333;
      text-decoration: none;
      margin: 0 10px;
    }
    footer a:hover {
      text-decoration: underline;
    }
    .carousel-item img{
    border-radius: 14px;
}

  
   </style>
</head>
<body>
   
<?php include 'components/user_header.php'; ?>
  <!-- Category Section and Slider -->
  <div class="row">
  <div class="col-md-3">
      <div class="category-section">
         <h3>Categories</h3>
         <ul class="category-list">
            <?php while ($category = $select_categories->fetch(PDO::FETCH_ASSOC)): ?>
               <li>
                  <?= $category['name']; ?>
                  <?php $subCategories = fetchSubCategories($conn, $category['id']); ?>
                  <?php if (!empty($subCategories)): ?>
                     <div class="sub-categories">
                        <ul>
                           <?php foreach ($subCategories as $subCategory): ?>
                              <li><?= $subCategory['name']; ?></li>
                           <?php endforeach; ?>
                        </ul>
                     </div>
                  <?php endif; ?>
               </li>
            <?php endwhile; ?>
         </ul>
      </div>
   </div>



    <div class="col-md-9">
      <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="./Crusel-img/Best-Size-For-ecommerce-Product-Images1-ezgif.com-webp-to-jpg-converter.jpg" class="d-block w-100" alt="Category 1">
          </div>
          <div class="carousel-item">
            <img src="./Crusel-img/Best-Size-For-ecommerce-Product-Images1-ezgif.com-webp-to-jpg-converter.jpg" class="d-block w-100" alt="Category 2">
          </div>
          <div class="carousel-item">
            <img src="./Crusel-img/Best-Size-For-ecommerce-Product-Images1-ezgif.com-webp-to-jpg-converter.jpg" class="d-block w-100" alt="Category 3">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </div>
<section class="container my-5">
   <h1 class="heading text-center">Latest Products</h1>
   <div class="product-container">

   <?php
     $select_products = $conn->prepare("SELECT * FROM `products` LIMIT 6"); 
     $select_products->execute();
     if($select_products->rowCount() > 0){
      while($fetch_product = $select_products->fetch(PDO::FETCH_ASSOC)){
   ?>
   <div class="product-item">
      <form action="" method="post" class="card">
         <input type="hidden" name="pid" value="<?= $fetch_product['id']; ?>">
         <input type="hidden" name="name" value="<?= $fetch_product['name']; ?>">
         <input type="hidden" name="price" value="<?= $fetch_product['price']; ?>">
         <input type="hidden" name="image" value="<?= $fetch_product['image_01']; ?>">
         <img src="uploaded_img/<?= $fetch_product['image_01']; ?>" class="product-img card-img-top" alt="">
         <div class="card-body">
            <h5 class="card-title"><?= $fetch_product['name']; ?></h5>
            <div class="d-flex justify-content-between align-items-center">
               <div class="price">Nrs.<?= $fetch_product['price']; ?>/-</div>
               <input type="number" name="qty" class="form-control w-25" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1">
            </div>
            <input type="submit" value="Add to Cart" class="btn btn-primary mt-3" name="add_to_cart">
            <button class="btn btn-outline-danger btn-wishlist" type="submit" name="add_to_wishlist"><i class="fas fa-heart"></i> Wishlist</button>
            <a href="quick_view.php?pid=<?= $fetch_product['id']; ?>" class="btn btn-outline-primary btn-quickview"><i class="fas fa-eye"></i> Quick View</a>
         </div>
      </form>
   </div>
   <?php
      }
   }else{
      echo '<p class="empty">No products added yet!</p>';
   }
   ?>

   </div>
</section>

<section class="container my-5">
   <h1 class="heading text-center">All Products</h1>
   <div class="product-container">

   <?php
     $select_products = $conn->prepare("SELECT * FROM `products`"); 
     $select_products->execute();
     if($select_products->rowCount() > 0){
      while($fetch_product = $select_products->fetch(PDO::FETCH_ASSOC)){
   ?>
   <div class="product-item">
      <form action="" method="post" class="card">
         <input type="hidden" name="pid" value="<?= $fetch_product['id']; ?>">
         <input type="hidden" name="name" value="<?= $fetch_product['name']; ?>">
         <input type="hidden" name="price" value="<?= $fetch_product['price']; ?>">
         <input type="hidden" name="image" value="<?= $fetch_product['image_01']; ?>">
         <img src="uploaded_img/<?= $fetch_product['image_01']; ?>" class="product-img card-img-top" alt="">
         <div class="card-body">
            <h5 class="card-title"><?= $fetch_product['name']; ?></h5>
            <div class="d-flex justify-content-between align-items-center">
               <div class="price">Nrs.<?= $fetch_product['price']; ?>/-</div>
               <input type="number" name="qty" class="form-control w-25" min="1" max="99" onkeypress="if(this.value.length == 2) return false;" value="1">
            </div>
            <input type="submit" value="Add to Cart" class="btn btn-primary mt-3" name="add_to_cart">
            <button class="btn btn-outline-danger btn-wishlist" type="submit" name="add_to_wishlist"><i class="fas fa-heart"></i> Wishlist</button>
            <a href="quick_view.php?pid=<?= $fetch_product['id']; ?>" class="btn btn-outline-primary btn-quickview"><i class="fas fa-eye"></i> Quick View</a>
         </div>
      </form>
   </div>
   <?php
      }
   }else{
      echo '<p class="empty">No products found!</p>';
   }
   ?>

   </div>
</section>

<?php include 'components/footer.php'; ?>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Your custom JavaScript file -->
<script src="js/script.js"></script>

<!-- Script to populate sub-categories based on selected category -->
<script>
   // Function to fetch and populate sub-categories based on selected category
   function loadSubCategories(categoryId) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', 'get_sub_categories.php?category_id=' + categoryId, true);

      xhr.onload = function() {
         if (xhr.status == 200) {
            var subCategorySelect = document.querySelector('select[name="sub_category"]');
            subCategorySelect.innerHTML = xhr.responseText;
         }
      };

      xhr.send();
   }

   // Event listener to trigger loadSubCategories on category change
   document.querySelector('select[name="category"]').addEventListener('change', function() {
      var categoryId = this.value;
      loadSubCategories(categoryId);
   });
</script>

</body>
</html>
</body>

