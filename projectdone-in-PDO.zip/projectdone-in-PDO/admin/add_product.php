<?php
include '../components/connect.php';

$message = [];

if (isset($_POST['add_product'])) {
    $product_name = $_POST['name'] ?? '';
    $product_price = $_POST['price'] ?? '';
    $product_description = $_POST['details'] ?? '';

    // Check if $_FILES['product_image'] is set and not empty
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        $product_image = $_FILES['product_image']['name'];
        $product_image_tmp_name = $_FILES['product_image']['tmp_name'];
        $product_image_size = $_FILES['product_image']['size'];
        $product_image_folder = '../uploaded_img/' . $product_image;

        if (empty($product_name) || empty($product_price) || empty($product_description) || empty($product_image)) {
            $message[] = 'Please fill out all fields.';
        } else {
            $insert_product = $conn->prepare("INSERT INTO `products`(`name`, `details`, `price`, `image_01`, `image_02`, `image_03`) 
                                             VALUES (?, ?, ?, ?, ?, ?)");
            $insert_product->execute([$product_name, $product_description, $product_price, $product_image, $product_image, $product_image]);

            if ($insert_product) {
                if ($product_image_size > 2000000) {
                    $message[] = "Image size is too large.";
                } else {
                    move_uploaded_file($product_image_tmp_name, $product_image_folder);
                    $message[] = 'New product added successfully.';
                    
                    // Redirect to products.php after adding product
                    header('Location: products.php');
                    exit(); // Ensure no further output is sent
                }
            }
        }
    } else {
        $message[] = 'Please upload a valid image file.';
    }
}

// Other parts of your script for update and delete operations



// Other parts of your script for update and delete operations


    if (isset($_POST['update_product'])){
        $product_name = $_POST['product_name'];
        $product_price = $_POST['product_price'];
        $product_description = $_POST['product_description'];
        $update_image = $_FILES['update_image']['name'];
        $update_image_tmp_name = $_FILES['update_image']['tmp_name'];
        $update_image_folder = '../uploaded_img/'.$update_image;

        $update_id = $_POST['update_id'];

        $update_query = $conn->prepare("UPDATE `products` SET name = ?, price = ?, description = ?, image = ? WHERE id = ?");
        $update_query->execute([$product_name, $product_price, $product_description, $update_image, $update_id]);
        if($update_query){
            if($update_image_size > 2000000){
            $message[] = " image size is too large";
        }else{
            move_uploaded_file($update_image_tmp_name, $update_image_folder);
            $message[] = 'product updated successfully';
        }
        }
    } 
    if (isset($_POST['delete_product'])){
        $delete_id = $_POST['delete_id'];
        $delete_image_query = $conn->prepare("SELECT image FROM `products` WHERE id = ?");
        $delete_image_query->execute([$delete_id]);
        $fetch_delete_image = $delete_image_query->fetch(PDO::FETCH_ASSOC);
        unlink('../uploaded_img/'.$fetch_delete_image['image']);
        $delete_query = $conn->prepare("DELETE FROM `products` WHERE id = ?");
        $delete_query->execute([$delete_id]);
        if($delete_query){
            $message[] = 'product deleted successfully';
        }
    } // Redirect to products.php after adding product
    header('Location: products.php');



?>








        