<?php
include '../components/connect.php';

if (isset($_GET['category_id'])) {
    $category_id = $_GET['category_id'];

    $select_sub_categories = $conn->prepare("SELECT * FROM `sub_categories` WHERE `category_id` = ?");
    $select_sub_categories->execute([$category_id]);

    $options = '<option value="" disabled selected>Select Sub-Category</option>';

    while ($sub_category = $select_sub_categories->fetch(PDO::FETCH_ASSOC)) {
        $options .= '<option value="' . $sub_category['id'] . '">' . $sub_category['name'] . '</option>';
    }

    echo $options;
}
?>
