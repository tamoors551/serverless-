<?php
include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:admin_login.php');
    exit(); // Ensure script stops after redirect
}

$message = [];

// Add Category
if (isset($_POST['add_category'])) {
    $category_name = $_POST['category_name'];
    $category_name = filter_var($category_name, FILTER_SANITIZE_STRING);

    if (empty($category_name)) {
        $message[] = 'Please enter a category name.';
    } else {
        $insert_category = $conn->prepare("INSERT INTO `categories`(`name`) VALUES(?)");
        $insert_category->execute([$category_name]);

        if ($insert_category) {
            $message[] = 'New category added successfully!';
        } else {
            $message[] = 'Failed to add category.';
        }
    }
}

// Add Sub-Category
if (isset($_POST['add_sub_category'])) {
    $category_id = $_POST['category_id'];
    $sub_category_name = $_POST['sub_category_name'];
    $sub_category_name = filter_var($sub_category_name, FILTER_SANITIZE_STRING);

    if (empty($category_id) || empty($sub_category_name)) {
        $message[] = 'Please select a category and enter a sub-category name.';
    } else {
        $insert_sub_category = $conn->prepare("INSERT INTO `sub_categories`(`category_id`, `name`) VALUES(?, ?)");
        $insert_sub_category->execute([$category_id, $sub_category_name]);

        if ($insert_sub_category) {
            $message[] = 'New sub-category added successfully!';
        } else {
            $message[] = 'Failed to add sub-category.';
        }
    }
}

// Delete Product
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];

    $delete_product_image = $conn->prepare("SELECT * FROM `products` WHERE `id` = ?");
    $delete_product_image->execute([$delete_id]);
    $fetch_delete_image = $delete_product_image->fetch(PDO::FETCH_ASSOC);
    unlink('../uploaded_img/' . $fetch_delete_image['image_01']);
    unlink('../uploaded_img/' . $fetch_delete_image['image_02']);
    unlink('../uploaded_img/' . $fetch_delete_image['image_03']);

    $delete_product = $conn->prepare("DELETE FROM `products` WHERE `id` = ?");
    $delete_product->execute([$delete_id]);

    $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE `pid` = ?");
    $delete_cart->execute([$delete_id]);

    $delete_wishlist = $conn->prepare("DELETE FROM `wishlist` WHERE `pid` = ?");
    $delete_wishlist->execute([$delete_id]);

    header('location: products.php');
    exit(); // Ensure script stops after redirect
}

// Fetch categories for dropdowns
$select_categories = $conn->prepare("SELECT * FROM `categories`");
$select_categories->execute();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="../css/admin_style.css">
</head>
<body>

<?php include '../components/admin_header.php'; ?>

<section class="add-products">

   <h1 class="heading">Add Product</h1>

   <!-- Add Category Form -->
   <div class="box add">
        <h3>Add New Category</h3>
        <form action="" method="post">
        <h3>Add New Category</h3>
            <input type="text" name="category_name" class="box" placeholder="Enter category name" maxlength="50" required>
            <input type="submit" value="Add Category" name="add_category" class="btn">
        </form>
    </div>

    <!-- Add Sub-Category Form -->
    <div class="box add">
        <h3>Add New Sub-Category</h3>
        <form action="" method="post">
        <h3>Add New Sub-Category</h3>

            <select name="category_id" id="category_id" class="box" required onchange="loadSubCategories(this.value)">
                <option value="" disabled selected>Select Category</option>
                <?php while ($category = $select_categories->fetch(PDO::FETCH_ASSOC)): ?>
                    <option value="<?= $category['id']; ?>"><?= $category['name']; ?></option>
                <?php endwhile; ?>
            </select>
            <input type="text" name="sub_category_name" id="sub_category_name" class="box" placeholder="Enter sub-category name" maxlength="50" required>
            <input type="submit" value="Add Sub-Category" name="add_sub_category" class="btn">
        </form>
    </div>

    <!-- Form to Add Product -->
    <form action="add_product.php" method="post" enctype="multipart/form-data">
        <div class="flex">
            <div class="inputBox">
                <span>Product Name (required)</span>
                <input type="text" class="box" required maxlength="100" placeholder="Enter product name" name="name">
            </div>
            <div class="inputBox">
                <span>Product Price (required)</span>
                <input type="number" min="0" class="box" required max="9999999999" placeholder="Enter product price" name="price">
            </div>
            <div class="inputBox">
                <span>Category (required)</span>
                <select name="category" id="category" class="box" required onchange="loadSubCategories(this.value)">
                    <option value="" disabled selected>Select Category</option>
                    <?php
                    $select_categories->execute();
                    while ($category = $select_categories->fetch(PDO::FETCH_ASSOC)) {
                        echo '<option value="' . $category['id'] . '">' . $category['name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="inputBox">
                <span>Sub-Category (required)</span>
                <select name="sub_category" id="sub_category" class="box" required>
                    <option value="" disabled selected>Select Sub-Category</option>
                    <!-- Options will be populated dynamically using JavaScript -->
                </select>
            </div>
            <div class="inputBox">
                <span>Image 01 (required)</span>
                <input type="file" name="image_01" accept="image/jpg, image/jpeg, image/png, image/webp" class="box" required>
            </div>
            <div class="inputBox">
                <span>Image 02 (required)</span>
                <input type="file" name="image_02" accept="image/jpg, image/jpeg, image/png, image/webp" class="box" required>
            </div>
            <div class="inputBox">
                <span>Image 03 (required)</span>
                <input type="file" name="image_03" accept="image/jpg, image/jpeg, image/png, image/webp" class="box" required>
            </div>
            <div class="inputBox">
                <span>Product description (required)</span>
                <textarea name="details" placeholder="Enter product details" class="box" required maxlength="500" cols="30" rows="10"></textarea>
            </div>
        </div>
        <input type="submit" value="Add Product" class="btn" name="add_product">
    </form>

</section>

<section class="show-products">

   <h1 class="heading">Products Added.</h1>

   <div class="box-container">

   <?php
      $select_products = $conn->prepare("SELECT * FROM `products`");
      $select_products->execute();
      if($select_products->rowCount() > 0){
         while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){ 
   ?>
   <div class="box">
      <img src="../uploaded_img/<?= $fetch_products['image_01']; ?>" alt="">
      <div class="name"><?= $fetch_products['name']; ?></div>
      <div class="price">Nrs.<span><?= $fetch_products['price']; ?></span>/-</div>
      <div class="details"><span><?= $fetch_products['details']; ?></span></div>
      <div class="flex-btn">
         <a href="update_product.php?update=<?= $fetch_products['id']; ?>" class="option-btn">update</a>
         <a href="products.php?delete=<?= $fetch_products['id']; ?>" class="delete-btn" onclick="return confirm('Delete this product?');">delete</a>
      </div>
   </div>
   <?php
         }
      } else {
         echo '<p class="empty">No products added yet!</p>';
      }
   ?>
   
   </div>

</section>

<!-- Display Messages -->
<section class="messages">
    <?php foreach ($message as $msg): ?>
        <div class="message"><?= $msg ?></div>
    <?php endforeach; ?>
</section>

<script src="../js/admin_script.js"></script>
<script>
    // Function to fetch and populate sub-categories based on selected category
    function loadSubCategories(categoryId) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'get_sub_categories.php?category_id=' + categoryId, true);

        xhr.onload = function() {
            if (xhr.status == 200) {
                var subCategorySelect = document.getElementById('sub_category');
                subCategorySelect.innerHTML = xhr.responseText;
            }
        };

        xhr.send();
    }
</script>
   
</body>
</html>
