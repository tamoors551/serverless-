<footer class="footer bg-dark text-light py-4">

   <section class="container">
      <div class="row">

         <div class="col-md-3">
            <h3 class="h5">Quick links</h3>
            <ul class="list-unstyled">
               <li><a href="home.php" class="text-light text-decoration-none"><i class="fas fa-angle-right me-2"></i>Home</a></li>
               <li><a href="about.php" class="text-light text-decoration-none"><i class="fas fa-angle-right me-2"></i>About</a></li>
               <li><a href="shop.php" class="text-light text-decoration-none"><i class="fas fa-angle-right me-2"></i>Shop</a></li>
               <li><a href="contact.php" class="text-light text-decoration-none"><i class="fas fa-angle-right me-2"></i>Contact</a></li>
            </ul>
         </div>

         <div class="col-md-3">
            <h3 class="h5">Extra links</h3>
            <ul class="list-unstyled">
               <li><a href="user_login.php" class="text-light text-decoration-none"><i class="fas fa-angle-right me-2"></i>Login</a></li>
               <li><a href="user_register.php" class="text-light text-decoration-none"><i class="fas fa-angle-right me-2"></i>Register</a></li>
               <li><a href="cart.php" class="text-light text-decoration-none"><i class="fas fa-angle-right me-2"></i>Cart</a></li>
               <li><a href="orders.php" class="text-light text-decoration-none"><i class="fas fa-angle-right me-2"></i>Orders</a></li>
            </ul>
         </div>

         <div class="col-md-3">
            <h3 class="h5">Contact Us</h3>
            <ul class="list-unstyled">
               <li><a href="tel:923051818044" class="text-light text-decoration-none"><i class="fas fa-phone me-2"></i>+923051818044</a></li>
               <li><a href="tel:923051818044" class="text-light text-decoration-none"><i class="fas fa-phone me-2"></i>+923051818044</a></li>
               <li><a href="mailto:tamoorsultan92@gmail.com" class="text-light text-decoration-none"><i class="fas fa-envelope me-2"></i>tamoorsultan92@gmail.com</a></li>
               <li><a href="https://www.google.com/maps/place/Rehmanpura+Colony,+Lahore,+Punjab+54000,+Pakistan/@31.5213355,74.3141785,16z/data=!3m1!4b1!4m6!3m5!1s0x3919048452bc69d5:0xe752b7eb6859f9cd!8m2!3d31.5215929!4d74.3184209!16s%2Fg%2F1thd520p?entry=ttu" target="_blank" class="text-light text-decoration-none"><i class="fas fa-map-marker-alt me-2"></i>Lahore, Pakistan</a></li>
            </ul>
         </div>

         <div class="col-md-3">
            <h3 class="h5">Follow Us</h3>
            <ul class="list-unstyled">
               <li><a href="https://www.facebook.com/tamoor.sultan.58760/" target="_blank" class="text-light text-decoration-none"><i class="fab fa-facebook-f me-2"></i>Facebook</a></li>
               <li><a href="https://www.facebook.com/tamoor.sultan.58760/" target="_blank" class="text-light text-decoration-none"><i class="fab fa-twitter me-2"></i>Twitter</a></li>
               <li><a href="https://www.instagram.com/tamoor.sultan.58760/" target="_blank" class="text-light text-decoration-none"><i class="fab fa-instagram me-2"></i>Instagram</a></li>
               <li><a href="https://www.linkedin.com/in/tamoor-sultan-58760/" target="_blank" class="text-light text-decoration-none"><i class="fab fa-linkedin me-2"></i>LinkedIn</a></li>
            </ul>
         </div>

      </div>
   </section>

   <div class="text-center mt-4">
      <div class="credit">&copy; <?= date('Y'); ?> by <span>M.Tamoor</span> | All rights reserved!</div>
   </div>

</footer>
