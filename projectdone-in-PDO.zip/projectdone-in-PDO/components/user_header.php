<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="alert alert-info alert-dismissible fade show" role="alert">
         <span>'.$message.'</span>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
      ';
   }
}
?>

<header class="header">

   <section class="container-fluid">
      <div class="d-flex justify-content-between align-items-center py-3">

         <a href="home.php" class="logo fs-3 text-decoration-none">E-<span>Shop</span></a>

         <nav class="navbar navbar-expand-lg navbar-light">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
               <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
               <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                     <a class="nav-link" href="home.php">Home</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="about.php">About Us</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="orders.php">Orders</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="shop.php">Shop Now</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="contact.php">Contact Us</a>
                  </li>
               </ul>
            </div>
         </nav>

         <div class="d-flex align-items-center">
            <?php
               $count_wishlist_items = $conn->prepare("SELECT * FROM `wishlist` WHERE user_id = ?");
               $count_wishlist_items->execute([$user_id]);
               $total_wishlist_counts = $count_wishlist_items->rowCount();

               $count_cart_items = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
               $count_cart_items->execute([$user_id]);
               $total_cart_counts = $count_cart_items->rowCount();
            ?>
            <a href="search_page.php" class="me-3 text-decoration-none">
               <i class="fas fa-search"></i> Search
            </a>
            <a href="wishlist.php" class="me-3 text-decoration-none">
               <i class="fas fa-heart"></i><span>(<?= $total_wishlist_counts; ?>)</span>
            </a>
            <a href="cart.php" class="me-3 text-decoration-none">
               <i class="fas fa-shopping-cart"></i><span>(<?= $total_cart_counts; ?>)</span>
            </a>
            <div class="dropdown">
               <a href="#" class="text-decoration-none" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="fas fa-user"></i>
               </a>
               <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                  <?php          
                     $select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
                     $select_profile->execute([$user_id]);
                     if($select_profile->rowCount() > 0){
                        $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
                  ?>
                  <li><p class="dropdown-item-text mb-0"><?= $fetch_profile["name"]; ?></p></li>
                  <li><a href="update_user.php" class="dropdown-item">Update Profile</a></li>
                  <li><a href="components/user_logout.php" class="dropdown-item text-danger" onclick="return confirm('Logout from the website?');">Logout</a></li>
                  <?php
                     }else{
                  ?>
                  <li><p class="dropdown-item-text mb-0">Please Login Or Register First to proceed!</p></li>
                  <li><a href="user_register.php" class="dropdown-item">Register</a></li>
                  <li><a href="user_login.php" class="dropdown-item">Login</a></li>
                  <?php
                     }
                  ?> 
               </ul>
            </div>
         </div>
      </div>
   </section>

</header>
